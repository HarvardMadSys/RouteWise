"""Shared helpers for section-based simulator experiments."""

from __future__ import annotations

import csv
import inspect
import json
import math
import multiprocessing
import pickle
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass, replace
from functools import cache
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np
from tqdm.auto import tqdm

from experiments.simulation.latency_factory import (
    DEFAULT_LATENCY_ANCHOR_KIND,
    LatencyAnchorKind,
    SyntheticLatencySpec,
    make_synthetic_ttft,
)
from experiments.subscriptions import (
    SubscriptionPlan,
    load_subscription_plans,
    subscription_fixed_cost_usd,
)
from rwsim.engine.simulator import Simulator
from rwsim.metrics import RunAggregate
from rwsim.metrics.histogram import merge_histograms
from rwsim.policies import build_policy
from rwsim.schemas import Request
from rwsim.world.capacity import (
    ConcurrencyState,
    MultiWindowQuotaState,
    ProviderTier,
    QuotaState,
    WeightedConcurrencyState,
)
from rwsim.world.distributions import LogNormal
from rwsim.world.providers import TieredProvider

if TYPE_CHECKING:
    from collections import Counter
    from collections.abc import Callable, Mapping

    from rwsim.metrics import Run
    from rwsim.world.scenarios import ScenarioConfig

ROOT_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT_DIR / "data"
OUTPUT_DIR = ROOT_DIR / "outputs" / "simulation"

P_SWEEP = (0.0, 0.25, 0.50, 0.75, 1.0)
COST_RATIO_PER_MILLION = (1.0, 2.0, 4.0)
OUTPUT_COST_MULTIPLIER = 5.0
DEFAULT_CACHED_INPUT_PRICE_FRACTION = 0.2
COST_LAYER_LATENCY_ANCHOR_MS = 300.0
DEFAULT_SEEDS = (42,)
DEFAULT_WORKLOAD = "burstgpt"
DEFAULT_TPS_P50 = 20.0
WORKLOAD_COST_ENVELOPE = "workload_p10_p90"
PREDICTOR_KIND_NONE = "none"
PREDICTOR_KIND_ORACLE = "oracle"
PREDICTOR_KIND_HISTOGRAM = "histogram"
PREDICTOR_KIND_EMA = "ema"
PREDICTOR_KIND_BUCKET_MEAN = "bucket_mean"
PREDICTOR_KIND_CONSTANT = "constant"
DEFAULT_OUTPUT_PREDICTOR = PREDICTOR_KIND_BUCKET_MEAN
SUPPORTED_PREDICTOR_KINDS: tuple[str, ...] = (
    PREDICTOR_KIND_NONE,
    PREDICTOR_KIND_ORACLE,
    PREDICTOR_KIND_HISTOGRAM,
    PREDICTOR_KIND_EMA,
    PREDICTOR_KIND_BUCKET_MEAN,
    "constant_mean",
    "constant_p1",
    "constant_p10",
    "constant_p25",
    "constant_p50",
    "constant_p75",
    "constant_p90",
    "constant_p99",
)
_WORKLOAD_CACHE_VERSION = 1

_WORKLOAD_PATHS = {
    "burstgpt": DATA_DIR / "burstgpt_30d.jsonl",
    "burstgpt_rednote": DATA_DIR / "burstgpt_rednote_30d.jsonl",
}
_TRACE_CACHE_WORKLOADS = ("freeinference", "rednote")
WORKLOAD_CHOICES = (*_WORKLOAD_PATHS, *_TRACE_CACHE_WORKLOADS)


@dataclass(frozen=True)
class SectionCell:
    """One independent section simulation cell."""

    scenario_name: str
    policy: str
    seed: int


@dataclass(frozen=True)
class SectionCellResult:
    """Result for one independent section simulation cell."""

    scenario_name: str
    policy: str
    seed: int
    run: Run


@dataclass(frozen=True)
class WorkloadTraceInfo:
    """Trace span used for paper-facing fixed-fee accounting."""

    n_requests: int
    start_sec: float
    end_sec: float
    span_sec: float
    trace_days: float


@dataclass
class SingleModelOutputPredictor:
    """Adapter that hides trace model labels from output-token predictors."""

    inner: Any
    model: str | None = None

    def predict(self, request: Request) -> Any:
        return self.inner.predict(self._single_model_request(request))

    def update(self, request: Request) -> None:
        self.inner.update(self._single_model_request(request))

    def reset(self) -> None:
        if hasattr(self.inner, "reset"):
            self.inner.reset()

    @property
    def is_warmed_up(self) -> bool:
        return bool(getattr(self.inner, "is_warmed_up", True))

    def _single_model_request(self, request: Request) -> Request:
        if request.model == self.model:
            return request
        return replace(request, model=self.model)


def p_label(value: float) -> str:
    """Return a stable policy-name suffix for one p-sweep value."""
    pct = round(float(value) * 100)
    if abs(float(value) - pct / 100.0) > 1e-9:
        raise ValueError(f"p values must be percent-like decimals, got {value!r}")
    return f"p{pct}"


def routewise_lp_policy_name(p_value: float) -> str:
    """Return the simulator policy name for LP-only RouteWise at one p value."""
    return f"ablation_lp_only_{p_label(p_value)}"


def routewise_hedging_policy_name(p_value: float) -> str:
    """Return the simulator policy name for LP+hedging RouteWise at one p value."""
    return f"ablation_lp_hedging_{p_label(p_value)}"


def make_routewise_presets(
    *,
    p_values: tuple[float, ...] = P_SWEEP,
    include_hedging: bool = False,
    cost_envelope: tuple[float, float] | str | None = WORKLOAD_COST_ENVELOPE,
    output_predictor: str | dict[str, Any] | None = DEFAULT_OUTPUT_PREDICTOR,
    output_predictor_quantile: str = "q50",
) -> dict[str, dict[str, Any]]:
    """Build section-local policy presets with explorer disabled.

    RouteWise uses bucket-mean output prediction by default for S_A LP cost.
    Pass ``None`` or ``"none"`` to use trace ``response_tokens`` instead.
    """
    predictor_spec = _normalize_predictor_arg(output_predictor)
    presets: dict[str, dict[str, Any]] = {
        "greedy_cost": {"policy": "BaselinePolicy", "params": {"mode": "greedy_cost"}},
        "greedy_latency": {"policy": "BaselinePolicy", "params": {"mode": "greedy_latency"}},
        "random": {"policy": "BaselinePolicy", "params": {"mode": "random"}},
        "or_sort_cost": {"policy": "BaselinePolicy", "params": {"mode": "or_sort_cost"}},
        "or_sort_latency": {"policy": "BaselinePolicy", "params": {"mode": "or_sort_latency"}},
    }
    for value in p_values:
        params: dict[str, Any] = {
            "hedging": False,
            "explorer": False,
            "p": float(value),
            "cost_envelope": cost_envelope,
        }
        if predictor_spec is not None:
            params["output_predictor_spec"] = dict(predictor_spec)
            params["output_predictor_quantile"] = output_predictor_quantile
        presets[routewise_lp_policy_name(value)] = {
            "policy": "RouteWisePolicy",
            "params": params,
        }
        if include_hedging:
            hedging_params: dict[str, Any] = {
                "hedging": "probability_target",
                "explorer": False,
                "p": float(value),
                "cost_envelope": cost_envelope,
            }
            if predictor_spec is not None:
                hedging_params["output_predictor_spec"] = dict(predictor_spec)
                hedging_params["output_predictor_quantile"] = output_predictor_quantile
            presets[routewise_hedging_policy_name(value)] = {
                "policy": "RouteWisePolicy",
                "params": hedging_params,
            }
    return presets


def _normalize_predictor_arg(
    arg: str | dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Convert a CLI-style predictor name into an internal spec dict."""
    if arg is None:
        return None
    if isinstance(arg, dict):
        return arg
    name = str(arg).strip()
    if not name or name.lower() == PREDICTOR_KIND_NONE:
        return None
    lower = name.lower()
    if lower == PREDICTOR_KIND_ORACLE:
        return {"kind": PREDICTOR_KIND_ORACLE}
    if lower == PREDICTOR_KIND_HISTOGRAM:
        return {"kind": PREDICTOR_KIND_HISTOGRAM}
    if lower == PREDICTOR_KIND_EMA:
        return {"kind": PREDICTOR_KIND_EMA}
    if lower == PREDICTOR_KIND_BUCKET_MEAN:
        return {"kind": PREDICTOR_KIND_BUCKET_MEAN}
    if lower.startswith("constant_"):
        return {
            "kind": PREDICTOR_KIND_CONSTANT,
            "calibration": lower.removeprefix("constant_"),
        }
    if lower.startswith("fixed:"):
        return {"kind": PREDICTOR_KIND_CONSTANT, "calibration": lower}
    raise ValueError(
        f"unknown predictor name {arg!r}; expected one of {SUPPORTED_PREDICTOR_KINDS} "
        "or 'fixed:<value>'."
    )


def make_ttft_distribution(
    family: str,
    anchor_ms: float = COST_LAYER_LATENCY_ANCHOR_MS,
    *,
    anchor_kind: LatencyAnchorKind = DEFAULT_LATENCY_ANCHOR_KIND,
):
    """Construct a synthetic TTFT distribution through the shared factory."""
    return make_synthetic_ttft(
        SyntheticLatencySpec(
            family=family,
            anchor_ms=anchor_ms,
            anchor_kind=anchor_kind,
        )
    )


def make_tps_distribution() -> LogNormal:
    """Return the default token-throughput distribution for synthetic providers."""
    return LogNormal(mu=math.log(DEFAULT_TPS_P50), sigma=0.3)


def make_api_provider(
    name: str,
    *,
    cost_per_million_tokens: float,
    output_cost_per_million_tokens: float | None = None,
    cached_input_price_fraction: float | None = None,
    latency_family: str,
    latency_anchor_ms: float = COST_LAYER_LATENCY_ANCHOR_MS,
    latency_anchor_kind: LatencyAnchorKind = DEFAULT_LATENCY_ANCHOR_KIND,
) -> TieredProvider:
    """Build an on-demand API provider."""
    output_price = (
        cost_per_million_tokens * OUTPUT_COST_MULTIPLIER
        if output_cost_per_million_tokens is None
        else output_cost_per_million_tokens
    )
    return TieredProvider(
        name=name,
        cost_per_token=cost_per_million_tokens / 1_000_000.0,
        input_cost_per_token=cost_per_million_tokens / 1_000_000.0,
        output_cost_per_token=output_price / 1_000_000.0,
        cached_input_cost_per_token=(
            None
            if cached_input_price_fraction is None
            else cost_per_million_tokens * cached_input_price_fraction / 1_000_000.0
        ),
        ttft_dist=make_ttft_distribution(
            latency_family,
            latency_anchor_ms,
            anchor_kind=latency_anchor_kind,
        ),
        tps_dist=make_tps_distribution(),
        tier=ProviderTier.S_A,
    )


def make_quota_provider(
    name: str,
    *,
    quota_size: int | None = None,
    plan: SubscriptionPlan | None = None,
    subscription_count: int = 1,
    latency_family: str = "heavy_tail",
    latency_anchor_ms: float = COST_LAYER_LATENCY_ANCHOR_MS,
    latency_anchor_kind: LatencyAnchorKind = DEFAULT_LATENCY_ANCHOR_KIND,
    quota_window_sec: float = 86400.0,
) -> TieredProvider:
    """Build a subscription/quota provider with zero marginal request cost."""
    if plan is not None and quota_size is not None:
        raise ValueError("make_quota_provider accepts either plan or quota_size, not both")
    if quota_size is not None and subscription_count != 1:
        raise ValueError("subscription_count requires plan=, not quota_size=")
    if subscription_count <= 0:
        raise ValueError(f"subscription_count must be > 0, got {subscription_count}")
    if plan is not None:
        quota_windows = tuple(
            QuotaState(
                size=subscription_count * quota_window.quota_requests,
                window_sec=quota_window.quota_window_sec,
            )
            for quota_window in plan.quota_windows
        )
        quota = (
            quota_windows[0]
            if len(quota_windows) == 1
            else MultiWindowQuotaState(quota_windows)
        )
    else:
        quota = None
    if quota_size is None:
        if quota is None:
            raise ValueError("make_quota_provider requires quota_size or plan")
    elif quota is None:
        quota = QuotaState(size=int(quota_size), window_sec=float(quota_window_sec))
    return TieredProvider(
        name=name,
        cost_per_token=0.0,
        input_cost_per_token=0.0,
        output_cost_per_token=0.0,
        ttft_dist=make_ttft_distribution(
            latency_family,
            latency_anchor_ms,
            anchor_kind=latency_anchor_kind,
        ),
        tps_dist=make_tps_distribution(),
        tier=ProviderTier.S_Q,
        quota=quota,
    )


def make_concurrency_provider(
    name: str,
    *,
    concurrency_limit: int | None = None,
    plan: SubscriptionPlan | None = None,
    concurrency_count: int = 1,
    model: str | None = None,
    latency_family: str = "heavy_tail",
    latency_anchor_ms: float = COST_LAYER_LATENCY_ANCHOR_MS,
    latency_anchor_kind: LatencyAnchorKind = DEFAULT_LATENCY_ANCHOR_KIND,
) -> TieredProvider:
    """Build a subscription/concurrency provider with zero marginal request cost."""
    if plan is not None and concurrency_limit is not None:
        raise ValueError(
            "make_concurrency_provider accepts either plan or concurrency_limit, not both"
        )
    if concurrency_count <= 0:
        raise ValueError(f"concurrency_count must be > 0, got {concurrency_count}")
    if plan is None:
        if model is not None:
            raise ValueError("model requires plan=")
        if concurrency_count != 1:
            raise ValueError("concurrency_count requires plan=")
        if concurrency_limit is None:
            raise ValueError("make_concurrency_provider requires concurrency_limit or plan")
        concurrency = ConcurrencyState(limit=int(concurrency_limit))
    else:
        if plan.tier != "concurrency":
            raise ValueError(
                f"make_concurrency_provider requires a concurrency plan, got {plan.tier!r}"
            )
        if plan.concurrency_allotment is None:
            raise ValueError(f"plan {plan.plan_id!r}: concurrency_allotment is required")
        resolution = plan.resolve_model_class_with_cost(model)
        if resolution is None:
            raise ValueError(
                f"plan {plan.plan_id!r}: model {model!r} is not supported by "
                "this concurrency plan"
            )
        concurrency = WeightedConcurrencyState(
            capacity_units=int(plan.concurrency_allotment) * int(concurrency_count),
            model_concurrency_costs_by_class=plan.model_concurrency_costs_by_class,
            fixed_model_class=resolution.model_class,
        )
    if concurrency.limit <= 0:
        raise ValueError(f"concurrency limit must be > 0, got {concurrency.limit}")
    return TieredProvider(
        name=name,
        cost_per_token=0.0,
        input_cost_per_token=0.0,
        output_cost_per_token=0.0,
        ttft_dist=make_ttft_distribution(
            latency_family,
            latency_anchor_ms,
            anchor_kind=latency_anchor_kind,
        ),
        tps_dist=make_tps_distribution(),
        tier=ProviderTier.S_C,
        concurrency=concurrency,
    )


@cache
def _load_cached_workload(dataset: str) -> tuple[Request, ...]:
    path = _workload_path(dataset)
    cache_path, manifest_path = _workload_cache_paths(path)
    if _workload_cache_is_valid(path, cache_path, manifest_path):
        try:
            with cache_path.open("rb") as handle:
                return tuple(pickle.load(handle))
        except (
            AttributeError,
            EOFError,
            ImportError,
            ValueError,
            pickle.UnpicklingError,
        ):
            pass
    return _build_workload_cache(path, cache_path, manifest_path)


def ensure_workload_cache(dataset: str = DEFAULT_WORKLOAD) -> Path:
    """Build the compact simulator workload cache if it is missing or stale."""
    if dataset in _TRACE_CACHE_WORKLOADS:
        from experiments.simulation.dataset_cache import _dataset_cache_path, ensure_caches

        ensure_caches([dataset])
        return _dataset_cache_path(dataset)
    path = _workload_path(dataset)
    cache_path, manifest_path = _workload_cache_paths(path)
    if not _workload_cache_is_valid(path, cache_path, manifest_path):
        _build_workload_cache(path, cache_path, manifest_path)
    return cache_path


def _workload_cache_paths(path: Path) -> tuple[Path, Path]:
    resolved = path.resolve()
    cache_path = resolved.with_name(f"{resolved.name}.simcache.pkl")
    manifest_path = resolved.with_name(f"{resolved.name}.simcache.manifest.json")
    return cache_path, manifest_path


def _workload_cache_fingerprint(path: Path) -> dict[str, Any]:
    resolved = path.resolve()
    stat = resolved.stat()
    return {
        "cache_version": _WORKLOAD_CACHE_VERSION,
        "source_path": str(path),
        "source_resolved": str(resolved),
        "source_size": stat.st_size,
        "source_mtime_ns": stat.st_mtime_ns,
    }


def _workload_cache_is_valid(path: Path, cache_path: Path, manifest_path: Path) -> bool:
    if not cache_path.exists() or not manifest_path.exists():
        return False
    try:
        with manifest_path.open() as handle:
            manifest = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return False
    fingerprint = _workload_cache_fingerprint(path)
    return all(manifest.get(key) == value for key, value in fingerprint.items())


def _build_workload_cache(
    path: Path,
    cache_path: Path,
    manifest_path: Path,
) -> tuple[Request, ...]:
    requests = tuple(_read_jsonl_workload(path))
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = cache_path.with_suffix(f".pkl.tmp.{multiprocessing.current_process().pid}")
    with tmp_path.open("wb") as handle:
        pickle.dump(requests, handle, protocol=pickle.HIGHEST_PROTOCOL)
    tmp_path.replace(cache_path)

    manifest = _workload_cache_fingerprint(path)
    manifest["n_requests"] = len(requests)
    manifest["cache_size"] = cache_path.stat().st_size
    tmp_manifest = manifest_path.with_suffix(
        f".json.tmp.{multiprocessing.current_process().pid}"
    )
    with tmp_manifest.open("w") as handle:
        json.dump(manifest, handle, indent=2, sort_keys=True)
    tmp_manifest.replace(manifest_path)
    _load_cached_workload.cache_clear()
    return requests


def _workload_path(dataset: str) -> Path:
    try:
        return _WORKLOAD_PATHS[dataset]
    except KeyError as exc:
        known = ", ".join(WORKLOAD_CHOICES)
        raise ValueError(f"unknown workload {dataset!r}; expected one of: {known}") from exc


@cache
def _load_cached_trace_workload(dataset: str) -> tuple[Request, ...]:
    """Load a dataset-cache workload and normalize it for simulator replay."""
    from experiments.simulation.dataset_cache import load_cached

    requests = tuple(load_cached(dataset))
    if not requests:
        return ()
    first_timestamp = float(requests[0].timestamp)
    return tuple(
        replace(
            request,
            id=index,
            timestamp=float(request.timestamp) - first_timestamp,
        )
        for index, request in enumerate(requests)
    )


def _read_jsonl_workload(
    path: Path,
    *,
    duration_sec: float | None = None,
    max_requests: int | None = None,
) -> list[Request]:
    if not path.exists():
        raise FileNotFoundError(f"workload file not found: {path}")

    requests: list[Request] = []
    first_timestamp: float | None = None
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            record = json.loads(line)
            timestamp = float(record["arrived_at"])
            if first_timestamp is None:
                first_timestamp = timestamp
            relative_timestamp = timestamp - first_timestamp
            if duration_sec is not None and relative_timestamp > duration_sec:
                break
            request_tokens = int(record["num_prefill_tokens"])
            response_tokens = int(record["num_decode_tokens"])
            total_tokens = request_tokens + response_tokens
            if total_tokens <= 0:
                continue
            metadata = {
                key: record[key]
                for key in (
                    "session_id",
                    "sharegpt_conversation_id",
                    "sharegpt_turn_index",
                    "log_type",
                    "elapsed_time_sec",
                )
                if key in record
            }
            requests.append(
                Request(
                    id=len(requests),
                    timestamp=relative_timestamp,
                    request_tokens=request_tokens,
                    response_tokens=response_tokens,
                    total_tokens=total_tokens,
                    model=str(record.get("model") or "sharegpt"),
                    metadata=metadata,
                )
            )
            if max_requests is not None and len(requests) >= max_requests:
                break
    return requests


def load_workload(
    *,
    dataset: str = DEFAULT_WORKLOAD,
    duration_sec: float | None = None,
    max_requests: int | None = None,
) -> list[Request]:
    """Load and optionally truncate the canonical trace workload.

    Full-trace loads use a compact pickle cache and return shared immutable
    ``Request`` objects from that cache. Callers must treat the returned
    requests and their metadata as read-only. Request IDs are dense simulator
    request indexes, not raw JSONL line numbers.
    """
    if dataset in _TRACE_CACHE_WORKLOADS:
        selected = _select_cached_requests(
            _load_cached_trace_workload(dataset),
            duration_sec=duration_sec,
            max_requests=max_requests,
        )
        return list(selected)
    path = _workload_path(dataset)
    cache_path, manifest_path = _workload_cache_paths(path)
    if (
        duration_sec is not None or max_requests is not None
    ) and not _workload_cache_is_valid(path, cache_path, manifest_path):
        return _read_jsonl_workload(
            path,
            duration_sec=duration_sec,
            max_requests=max_requests,
        )

    selected = _select_cached_requests(
        _load_cached_workload(dataset),
        duration_sec=duration_sec,
        max_requests=max_requests,
    )
    return list(selected)


def workload_trace_info(requests: list[Request]) -> WorkloadTraceInfo:
    """Return stable trace-span metadata for section summaries."""
    if not requests:
        return WorkloadTraceInfo(
            n_requests=0,
            start_sec=0.0,
            end_sec=0.0,
            span_sec=0.0,
            trace_days=0.0,
        )
    start = float(requests[0].timestamp)
    end = float(requests[-1].timestamp)
    span = max(end - start, 0.0)
    return WorkloadTraceInfo(
        n_requests=len(requests),
        start_sec=start,
        end_sec=end,
        span_sec=span,
        trace_days=span / 86400.0,
    )


def _select_cached_requests(
    requests: tuple[Request, ...],
    *,
    duration_sec: float | None,
    max_requests: int | None,
) -> tuple[Request, ...]:
    stop = len(requests)
    if duration_sec is not None:
        for index, request in enumerate(requests):
            if request.timestamp > duration_sec:
                stop = index
                break
    if max_requests is not None:
        stop = min(stop, max_requests)
    return requests[:stop]


def run_policy(
    scenario: ScenarioConfig,
    requests: list[Request],
    policy_name: str,
    *,
    presets: dict[str, dict[str, Any]],
    seed: int,
    retain_records: bool = True,
) -> Run:
    """Run a section-local policy preset on one request stream."""
    materialized = _materialize_workload_cost_envelope(
        presets,
        policy_name=policy_name,
        scenario=scenario,
        requests=requests,
    )
    materialized = _materialize_workload_predictor(
        materialized,
        policy_name=policy_name,
        requests=requests,
    )
    policy = build_policy(
        policy_name,
        presets=materialized,
        seed=seed,
    )
    simulator = Simulator(scenario=scenario, seed=seed, retain_records=retain_records)
    return simulator.run(requests, policy, policy_name=policy_name)


def _materialize_workload_predictor(
    presets: dict[str, dict[str, Any]],
    *,
    policy_name: str,
    requests: list[Request],
) -> dict[str, dict[str, Any]]:
    """Replace an output-predictor spec with a concrete predictor instance."""
    try:
        preset = presets[policy_name]
    except KeyError:
        return presets
    params = dict(preset.get("params", {}))
    spec = params.pop("output_predictor_spec", None)
    if spec is None:
        return presets

    params["output_predictor"] = _build_workload_predictor(spec, requests=requests)
    patched = dict(presets)
    patched[policy_name] = {**preset, "params": params}
    return patched


def _build_workload_predictor(
    spec: dict[str, Any],
    *,
    requests: list[Request],
) -> Any:
    """Materialize one predictor spec into a concrete predictor instance."""
    kind = str(spec.get("kind", "")).lower()
    if kind == PREDICTOR_KIND_ORACLE:
        from experiments.offline_stage.value_estimators import OracleOutputPredictor

        return OracleOutputPredictor()
    if kind == PREDICTOR_KIND_HISTOGRAM:
        from experiments.offline_stage.value_estimators import HistogramOutputPredictor

        return SingleModelOutputPredictor(HistogramOutputPredictor())
    if kind == PREDICTOR_KIND_EMA:
        from experiments.offline_stage.value_estimators import EMAOutputPredictor

        return SingleModelOutputPredictor(EMAOutputPredictor())
    if kind == PREDICTOR_KIND_BUCKET_MEAN:
        from experiments.offline_stage.value_estimators import BucketMeanOutputPredictor

        return BucketMeanOutputPredictor()
    if kind == PREDICTOR_KIND_CONSTANT:
        from experiments.offline_stage.value_estimators import (
            ConstantOutputPredictor,
            workload_constant_value,
        )

        calibration = str(spec.get("calibration", "mean"))
        value = workload_constant_value(requests, kind=calibration)
        return ConstantOutputPredictor(value=value, label=f"constant_{calibration}")
    raise ValueError(f"unknown predictor spec kind {kind!r}")


def _materialize_workload_cost_envelope(
    presets: dict[str, dict[str, Any]],
    *,
    policy_name: str,
    scenario: ScenarioConfig,
    requests: list[Request],
) -> dict[str, dict[str, Any]]:
    """Replace the workload-envelope sentinel with concrete P10/P90 bounds."""
    try:
        preset = presets[policy_name]
    except KeyError:
        return presets
    params = dict(preset.get("params", {}))
    if params.get("cost_envelope") != WORKLOAD_COST_ENVELOPE:
        return presets

    params["cost_envelope"] = _cached_workload_cost_envelope(
        _provider_cost_envelope_key(scenario.providers),
        _request_cost_envelope_key(requests),
    )
    patched = dict(presets)
    patched[policy_name] = {**preset, "params": params}
    return patched


@cache
def _cached_workload_cost_envelope(
    provider_key: tuple[tuple[float, float], ...],
    request_key: tuple[tuple[int, float], ...],
) -> tuple[float, float]:
    values = [
        min(
            input_cost * request_tokens + output_cost * response_tokens
            for input_cost, output_cost in provider_key
        )
        for request_tokens, response_tokens in request_key
    ]
    return _cost_envelope_from_values(values)


def workload_cost_envelope(
    providers: list[TieredProvider],
    requests: list[Request],
    *,
    lower_percentile: float = 10.0,
    upper_percentile: float = 90.0,
    floor_ratio: float = 1e-3,
) -> tuple[float, float]:
    """Calibrate L/U from cheapest API-equivalent request costs."""
    values = [
        _cheapest_api_cost_for_request(providers, request)
        for request in requests
    ]
    values = [value for value in values if value is not None and value > 0.0]
    return _cost_envelope_from_values(
        values,
        lower_percentile=lower_percentile,
        upper_percentile=upper_percentile,
        floor_ratio=floor_ratio,
    )


def _cost_envelope_from_values(
    values: list[float],
    *,
    lower_percentile: float = 10.0,
    upper_percentile: float = 90.0,
    floor_ratio: float = 1e-3,
) -> tuple[float, float]:
    if not values:
        raise ValueError(
            "Cannot compute RouteWise cost envelope: no positive S_A API request "
            "costs were found in the workload."
        )

    costs = np.asarray(values, dtype=float)
    L = float(np.percentile(costs, lower_percentile))
    U = float(np.percentile(costs, upper_percentile))
    if not (math.isfinite(L) and math.isfinite(U)) or U <= 0.0:
        raise ValueError(
            "Cannot compute RouteWise cost envelope from non-finite or non-positive "
            f"bounds: L={L}, U={U}"
        )
    if L <= 0.0 or L >= U:
        L = max(U * floor_ratio, 1e-9)
    return (L, U)


def _provider_cost_envelope_key(
    providers: list[TieredProvider],
) -> tuple[tuple[float, float], ...]:
    return tuple(
        (
            float(provider.effective_input_cost_per_token),
            float(provider.effective_output_cost_per_token),
        )
        for provider in providers
        if provider.tier == ProviderTier.S_A
        and (
            provider.effective_input_cost_per_token > 0.0
            or provider.effective_output_cost_per_token > 0.0
        )
    )


def _request_cost_envelope_key(
    requests: list[Request],
) -> tuple[tuple[int, float], ...]:
    key: list[tuple[int, float]] = []
    for request in requests:
        request_tokens = int(getattr(request, "request_tokens", 0) or 0)
        response_tokens = getattr(request, "response_tokens", None)
        if response_tokens is None:
            response_tokens = getattr(request, "estimated_response_tokens", None)
        total_tokens = getattr(request, "total_tokens", None)
        if response_tokens is None:
            response_tokens = max(int(total_tokens or 0) - request_tokens, 0)
        key.append((request_tokens, float(response_tokens)))
    return tuple(key)


def _cheapest_api_cost_for_request(
    providers: list[TieredProvider],
    request: Request,
) -> float | None:
    api_costs = [
        provider.marginal_cost_for_request(request, 0.0)
        for provider in providers
        if provider.tier == ProviderTier.S_A
        and (
            provider.effective_input_cost_per_token > 0.0
            or provider.effective_output_cost_per_token > 0.0
        )
    ]
    if not api_costs:
        return None
    return min(api_costs)


def quota_fits_in_trace(
    plan: SubscriptionPlan,
    *,
    subscription_count: int,
    requests: list[Request],
) -> bool:
    """Return whether quota capacity can cover every request window.

    This is true when every quota window has enough aggregate capacity to cover
    every request in that window. Such runs do not exercise quota scarcity and
    should be excluded from main q-sweep plots.
    """
    if not requests:
        return True
    trace_start = float(requests[0].timestamp)
    for quota_window in plan.quota_windows:
        capacity = quota_window.quota_requests * int(subscription_count)
        counts: dict[int, int] = {}
        for request in requests:
            window_id = int(
                (float(request.timestamp) - trace_start)
                // quota_window.quota_window_sec
            )
            counts[window_id] = counts.get(window_id, 0) + 1
        if any(count > capacity for count in counts.values()):
            return False
    return True


def concurrency_saturated_in_trace(
    plan: SubscriptionPlan,
    *,
    concurrency_count: int,
    model: str,
    requests: list[Request],
    p50_service_time_ms: float | None = None,
) -> bool:
    """Return whether the trace reaches or exceeds weighted concurrency capacity."""
    return bool(
        _concurrency_trace_metrics(
            plan,
            concurrency_count=concurrency_count,
            model=model,
            requests=requests,
            p50_service_time_ms=p50_service_time_ms,
        )["concurrency_saturated_in_trace"]
    )


def _concurrency_trace_metrics(
    plan: SubscriptionPlan,
    *,
    concurrency_count: int,
    model: str,
    requests: list[Request],
    trace_duration_sec: float | None = None,
    p50_service_time_ms: float | None = None,
) -> dict[str, float | int | bool]:
    if not requests:
        return {
            "peak_used_concurrency_cost": 0,
            "mean_concurrency_utilization": 0.0,
            "concurrency_saturated_in_trace": False,
        }
    if plan.concurrency_allotment is None:
        raise ValueError(f"plan {plan.plan_id!r}: concurrency_allotment is required")
    if concurrency_count <= 0:
        raise ValueError(f"concurrency_count must be > 0, got {concurrency_count}")
    resolution = plan.resolve_model_class_with_cost(model)
    if resolution is None:
        raise ValueError(f"plan {plan.plan_id!r}: model {model!r} is not supported")

    capacity_units = int(plan.concurrency_allotment) * int(concurrency_count)
    request_cost = int(resolution.cost)
    active: list[tuple[float, int]] = []
    peak_used = 0
    total_capacity_unit_seconds_used = 0.0
    saturated = False

    for request in sorted(requests, key=lambda item: (float(item.timestamp), item.id)):
        now = float(request.timestamp)
        active = [(finish, cost) for finish, cost in active if finish > now]
        used = sum(cost for _, cost in active)
        service_time_sec = _estimated_concurrency_service_time_sec(
            request,
            p50_service_time_ms=p50_service_time_ms,
        )
        if used + request_cost >= capacity_units:
            saturated = True
        if used + request_cost <= capacity_units:
            active.append((now + service_time_sec, request_cost))
            total_capacity_unit_seconds_used += request_cost * service_time_sec
            peak_used = max(peak_used, used + request_cost)
        else:
            peak_used = max(peak_used, used)

    if trace_duration_sec is None:
        trace_duration_sec = workload_trace_info(requests).span_sec
    denominator = capacity_units * max(float(trace_duration_sec), 0.0)
    mean_utilization = (
        total_capacity_unit_seconds_used / denominator if denominator > 0.0 else 0.0
    )
    return {
        "peak_used_concurrency_cost": peak_used,
        "mean_concurrency_utilization": min(mean_utilization, 1.0),
        "concurrency_saturated_in_trace": saturated,
    }


def _estimated_concurrency_service_time_sec(
    request: Request,
    *,
    p50_service_time_ms: float | None = None,
) -> float:
    """Estimate service time for saturation screening.

    The actual simulator samples TTFT/TPS from provider distributions; this
    deterministic proxy keeps the section-level capacity gate policy-independent.
    """
    if p50_service_time_ms is not None:
        return max(float(p50_service_time_ms), 0.0) / 1000.0
    response_tokens = request.response_tokens or 1
    return (
        COST_LAYER_LATENCY_ANCHOR_MS
        + (response_tokens / DEFAULT_TPS_P50) * 1000.0
    ) / 1000.0


def _subscription_summary_fields(
    *,
    scenario: ScenarioConfig,
    requests: list[Request],
    trace_info: WorkloadTraceInfo,
    api_cost_usd: float,
    mean_denominator: int,
    run_count: int,
) -> dict[str, Any]:
    metadata = dict(getattr(scenario, "metadata", {}) or {})
    plan_id = metadata.get("subscription_plan")
    concurrency_plan_id = metadata.get("concurrency_plan")
    fields: dict[str, Any] = {
        "public_scenario": metadata.get("public_scenario", scenario.name),
        "artifact_label": metadata.get("artifact_label", scenario.name),
        "subscription_plan": plan_id,
        "subscription_plan_display_name": None,
        "subscription_count": metadata.get("subscription_count"),
        "concurrency_plan": concurrency_plan_id,
        "concurrency_plan_display_name": metadata.get("concurrency_plan_display_name"),
        "concurrency_count": metadata.get("concurrency_count"),
        "model": metadata.get("model"),
        "model_class": metadata.get("model_class"),
        "model_concurrency_cost": metadata.get("model_concurrency_cost"),
        "prefix_cache_enabled": metadata.get("prefix_cache_enabled"),
        "cached_input_price_fraction": metadata.get("cached_input_price_fraction"),
        "concurrency_capacity_units": metadata.get("concurrency_capacity_units"),
        "effective_concurrency_limit": metadata.get("effective_concurrency_limit"),
        "latency_profile": metadata.get("latency_profile"),
        "latency_generation_version": metadata.get("latency_generation_version"),
        "latency_family": metadata.get("latency_family"),
        "latency_anchor_kind": metadata.get("latency_anchor_kind"),
        "latency_anchor_ms": metadata.get("latency_anchor_ms"),
        "latency_distribution_mean_ms": metadata.get("latency_distribution_mean_ms"),
        "latency_distribution_p50_ms": metadata.get("latency_distribution_p50_ms"),
        "latency_shape": metadata.get("latency_shape"),
        "quota_latency_profile_provider": metadata.get("quota_latency_profile_provider"),
        "concurrency_latency_profile_provider": metadata.get(
            "concurrency_latency_profile_provider"
        ),
        "api_latency_family": metadata.get("api_latency_family"),
        "api_latency_generation_version": metadata.get("api_latency_generation_version"),
        "api_latency_anchor_kind": metadata.get("api_latency_anchor_kind"),
        "api_latency_anchor_ms": metadata.get("api_latency_anchor_ms"),
        "api_latency_distribution_mean_ms": metadata.get(
            "api_latency_distribution_mean_ms"
        ),
        "api_latency_distribution_p50_ms": metadata.get(
            "api_latency_distribution_p50_ms"
        ),
        "api_latency_shape": metadata.get("api_latency_shape"),
        "peak_used_concurrency_cost": None,
        "mean_concurrency_utilization": None,
        "concurrency_saturated_in_trace": None,
        "run_count": run_count,
        "api_cost_usd": float(api_cost_usd),
        "api_cost_usd_per_run": (
            float(api_cost_usd) / run_count if run_count else float("nan")
        ),
        "subscription_fixed_cost_usd": 0.0,
        "subscription_fixed_cost_usd_per_run": 0.0,
        "total_cost_usd": float(api_cost_usd),
        "total_cost_usd_per_run": (
            float(api_cost_usd) / run_count if run_count else float("nan")
        ),
        "mean_api_cost_usd": (
            float(api_cost_usd) / mean_denominator
            if mean_denominator
            else float("nan")
        ),
        "mean_total_cost_usd": (
            float(api_cost_usd) / mean_denominator
            if mean_denominator
            else float("nan")
        ),
        "subscription_cost_known": True,
        "cost_claim_allowed": True,
        "trace_paper_grade": True,
        "quota_fits_in_trace": None,
        "trace_days": trace_info.trace_days,
    }
    if plan_id is None and concurrency_plan_id is None:
        return fields

    if plan_id is not None and concurrency_plan_id is not None:
        quota_plan = load_subscription_plans()[str(plan_id)]
        concurrency_plan = load_subscription_plans()[str(concurrency_plan_id)]
        quota_count = int(metadata.get("subscription_count") or 1)
        concurrency_count = int(metadata.get("concurrency_count") or 1)
        quota_fixed_cost_per_run = subscription_fixed_cost_usd(
            quota_plan,
            subscription_count=quota_count,
            trace_days=trace_info.trace_days,
        )
        concurrency_fixed_cost_per_run = subscription_fixed_cost_usd(
            concurrency_plan,
            subscription_count=concurrency_count,
            trace_days=trace_info.trace_days,
        )
        fixed_cost_per_run = quota_fixed_cost_per_run + concurrency_fixed_cost_per_run
        fixed_cost = fixed_cost_per_run * run_count
        total_cost = float(api_cost_usd) + fixed_cost
        min_window_sec = min(window.quota_window_sec for window in quota_plan.quota_windows)
        quota_paper_grade = trace_info.trace_days >= 5.0 * min_window_sec / 86400.0
        concurrency_paper_grade = trace_info.trace_days >= 5.0
        model = str(metadata.get("model") or "")
        concurrency_metrics = _concurrency_trace_metrics(
            concurrency_plan,
            concurrency_count=concurrency_count,
            model=model,
            requests=requests,
            trace_duration_sec=trace_info.span_sec,
        )
        fields.update(
            {
                "subscription_plan": quota_plan.plan_id,
                "subscription_plan_display_name": quota_plan.display_name,
                "subscription_count": quota_count,
                "concurrency_plan": concurrency_plan.plan_id,
                "concurrency_plan_display_name": concurrency_plan.display_name,
                "concurrency_count": concurrency_count,
                "subscription_fixed_cost_usd": fixed_cost,
                "subscription_fixed_cost_usd_per_run": fixed_cost_per_run,
                "total_cost_usd": total_cost,
                "total_cost_usd_per_run": (
                    total_cost / run_count if run_count else float("nan")
                ),
                "mean_total_cost_usd": (
                    total_cost / mean_denominator
                    if mean_denominator
                    else float("nan")
                ),
                "subscription_cost_known": (
                    quota_plan.subscription_cost_known
                    and concurrency_plan.subscription_cost_known
                ),
                "cost_claim_allowed": (
                    quota_plan.cost_claim_allowed and concurrency_plan.cost_claim_allowed
                ),
                "trace_paper_grade": quota_paper_grade and concurrency_paper_grade,
                "quota_fits_in_trace": quota_fits_in_trace(
                    quota_plan,
                    subscription_count=quota_count,
                    requests=requests,
                ),
                "peak_used_concurrency_cost": concurrency_metrics[
                    "peak_used_concurrency_cost"
                ],
                "mean_concurrency_utilization": concurrency_metrics[
                    "mean_concurrency_utilization"
                ],
                "concurrency_saturated_in_trace": concurrency_metrics[
                    "concurrency_saturated_in_trace"
                ],
            }
        )
        return fields

    if plan_id is not None:
        plan = load_subscription_plans()[str(plan_id)]
        count = int(metadata.get("subscription_count") or 1)
    else:
        plan = load_subscription_plans()[str(concurrency_plan_id)]
        count = int(metadata.get("concurrency_count") or 1)
    fixed_cost_per_run = subscription_fixed_cost_usd(
        plan,
        subscription_count=count,
        trace_days=trace_info.trace_days,
    )
    fixed_cost = fixed_cost_per_run * run_count
    total_cost = float(api_cost_usd) + fixed_cost
    common_plan_fields = {
        "subscription_fixed_cost_usd": fixed_cost,
        "subscription_fixed_cost_usd_per_run": fixed_cost_per_run,
        "total_cost_usd": total_cost,
        "total_cost_usd_per_run": (
            total_cost / run_count if run_count else float("nan")
        ),
        "mean_total_cost_usd": (
            total_cost / mean_denominator
            if mean_denominator
            else float("nan")
        ),
        "subscription_cost_known": plan.subscription_cost_known,
        "cost_claim_allowed": plan.cost_claim_allowed,
    }
    fields.update(common_plan_fields)
    if plan_id is not None:
        min_window_sec = min(window.quota_window_sec for window in plan.quota_windows)
        trace_paper_grade = trace_info.trace_days >= 5.0 * min_window_sec / 86400.0
        fields.update(
            {
                "subscription_plan": plan.plan_id,
                "subscription_plan_display_name": plan.display_name,
                "subscription_count": count,
                "trace_paper_grade": trace_paper_grade,
                "quota_fits_in_trace": quota_fits_in_trace(
                    plan,
                    subscription_count=count,
                    requests=requests,
                ),
            }
        )
    else:
        model = str(metadata.get("model") or "")
        concurrency_metrics = _concurrency_trace_metrics(
            plan,
            concurrency_count=count,
            model=model,
            requests=requests,
            trace_duration_sec=trace_info.span_sec,
        )
        # §1.3 Featherless-style subscriptions use monthly fixed fees; require
        # at least five trace days before treating prorated cost as paper-grade.
        trace_paper_grade = trace_info.trace_days >= 5.0
        fields.update(
            {
                "concurrency_plan": plan.plan_id,
                "concurrency_plan_display_name": plan.display_name,
                "concurrency_count": count,
                "trace_paper_grade": trace_paper_grade,
                "peak_used_concurrency_cost": concurrency_metrics[
                    "peak_used_concurrency_cost"
                ],
                "mean_concurrency_utilization": concurrency_metrics[
                    "mean_concurrency_utilization"
                ],
                "concurrency_saturated_in_trace": concurrency_metrics[
                    "concurrency_saturated_in_trace"
                ],
            }
        )
    return fields


def summarize_runs(
    *,
    scenario: ScenarioConfig,
    policy: str,
    seeds: tuple[int, ...],
    runs: list[Run],
    requests: list[Request] | None = None,
    trace_info: WorkloadTraceInfo | None = None,
) -> dict[str, Any]:
    """Aggregate section metrics across seeds."""
    aggregate = _merge_run_aggregates(runs)
    total = aggregate.n
    ttft_histogram = aggregate.ttft_histogram
    trace_info = trace_info or workload_trace_info(requests or [])
    api_cost_usd = float(aggregate.total_cost_usd)

    def percentile(pct: float) -> float:
        if total == 0:
            return float("nan")
        return ttft_histogram.quantile(pct / 100.0)

    row = {
        "scenario": scenario.name,
        "policy": policy,
        "seeds": list(seeds),
        "n_requests": total,
        "mean_ttft_ms": ttft_histogram.mean(),
        "p10_ms": percentile(10),
        "p25_ms": percentile(25),
        "p50_ms": percentile(50),
        "p75_ms": percentile(75),
        "p90_ms": percentile(90),
        "p99_ms": percentile(99),
        "slo_violation_rate": (
            aggregate.slo_violated_count / total if total else 0.0
        ),
        "hedge_rate": (
            aggregate.hedge_triggered_count / aggregate.hedge_total_count
            if aggregate.hedge_total_count
            else 0.0
        ),
        "provider_mix": _fraction_map(aggregate.provider_counts, total),
        "tier_mix": _fraction_map(aggregate.tier_counts, total),
        "percentile_source": "histogram",
        "histogram_bins": int(ttft_histogram.bin_edges_ms.size - 1),
    }
    row.update(
        _subscription_summary_fields(
            scenario=scenario,
            requests=requests or [],
            trace_info=trace_info,
            api_cost_usd=api_cost_usd,
            mean_denominator=aggregate.cost_count,
            run_count=len(runs),
        )
    )
    return row


def run_section(
    *,
    section_name: str,
    scenarios: dict[str, ScenarioConfig],
    policies: tuple[str, ...],
    presets: dict[str, dict[str, Any]],
    seeds: tuple[int, ...],
    section_runners: Mapping[str, Callable[[ScenarioConfig, list[Request], int], Run]] | None = None,
    parallel_cell_runner: Callable[
        [SectionCell, dict[str, dict[str, Any]], str, float | None, int | None, bool],
        SectionCellResult,
    ]
    | None = None,
    workload_dataset: str = DEFAULT_WORKLOAD,
    duration_sec: float | None = None,
    max_requests: int | None = None,
    output_dir: Path | None = None,
    retain_records: bool = False,
    jobs: int = 1,
) -> list[dict[str, Any]]:
    """Run one section and write machine-readable summaries."""
    if jobs < 1:
        raise ValueError(f"jobs must be >= 1, got {jobs}")
    root = output_dir or (OUTPUT_DIR / section_name.replace("-", "_"))
    root.mkdir(parents=True, exist_ok=True)
    cells = [
        SectionCell(scenario.name, policy, seed)
        for scenario in scenarios.values()
        for policy in policies
        for seed in seeds
    ]
    if jobs == 1:
        results, requests = _run_section_serial(
            scenarios=scenarios,
            cells=cells,
            presets=presets,
            section_runners=section_runners or {},
            workload_dataset=workload_dataset,
            duration_sec=duration_sec,
            max_requests=max_requests,
            retain_records=retain_records,
        )
        execution_mode = "serial"
    else:
        if parallel_cell_runner is None:
            raise ValueError(
                "parallel run_section requires a section-local parallel_cell_runner"
            )
        ensure_workload_cache(workload_dataset)
        results = _run_section_parallel(
            cells=cells,
            presets=presets,
            workload_dataset=workload_dataset,
            duration_sec=duration_sec,
            max_requests=max_requests,
            retain_records=retain_records,
            jobs=jobs,
            parallel_cell_runner=parallel_cell_runner,
        )
        requests = load_workload(
            dataset=workload_dataset,
            duration_sec=duration_sec,
            max_requests=max_requests,
        )
        execution_mode = "parallel"

    rows = _write_section_outputs(
        root=root,
        section_name=section_name,
        scenarios=scenarios,
        policies=policies,
        seeds=seeds,
        results=results,
        workload_dataset=workload_dataset,
        duration_sec=duration_sec,
        max_requests=max_requests,
        requests=requests,
        jobs=jobs,
        execution_mode=execution_mode,
    )
    return rows


def _run_section_serial(
    *,
    scenarios: dict[str, ScenarioConfig],
    cells: list[SectionCell],
    presets: dict[str, dict[str, Any]],
    section_runners: Mapping[str, Callable[[ScenarioConfig, list[Request], int], Run]],
    workload_dataset: str,
    duration_sec: float | None,
    max_requests: int | None,
    retain_records: bool,
) -> tuple[list[SectionCellResult], list[Request]]:
    requests = load_workload(
        dataset=workload_dataset,
        duration_sec=duration_sec,
        max_requests=max_requests,
    )
    results: list[SectionCellResult] = []
    with _section_progress(cells, total=len(cells), desc="RouteWise cells") as progress:
        for cell in progress:
            _set_progress_cell(progress, cell)
            scenario = scenarios[cell.scenario_name]
            if cell.policy in section_runners:
                run = section_runners[cell.policy](
                    scenario,
                    requests,
                    cell.seed,
                    retain_records=retain_records,
                )
            else:
                run = run_policy(
                    scenario,
                    requests,
                    cell.policy,
                    presets=presets,
                    seed=cell.seed,
                    retain_records=retain_records,
                )
            results.append(
                SectionCellResult(
                    scenario_name=cell.scenario_name,
                    policy=cell.policy,
                    seed=cell.seed,
                    run=run,
                )
            )
    return results, requests


def _run_section_parallel(
    *,
    cells: list[SectionCell],
    presets: dict[str, dict[str, Any]],
    workload_dataset: str,
    duration_sec: float | None,
    max_requests: int | None,
    retain_records: bool,
    jobs: int,
    parallel_cell_runner: Callable[
        [SectionCell, dict[str, dict[str, Any]], str, float | None, int | None, bool],
        SectionCellResult,
    ],
) -> list[SectionCellResult]:
    if not cells:
        return []
    context = multiprocessing.get_context("spawn")
    max_workers = min(jobs, len(cells))
    results: list[SectionCellResult] = []
    executor_kwargs: dict[str, Any] = {
        "max_workers": max_workers,
        "mp_context": context,
    }
    if "max_tasks_per_child" in inspect.signature(ProcessPoolExecutor).parameters:
        tasks_per_worker = math.ceil(len(cells) / max_workers)
        executor_kwargs["max_tasks_per_child"] = max(10, tasks_per_worker + 1)
    with ProcessPoolExecutor(**executor_kwargs) as executor:
        futures = [
            executor.submit(
                parallel_cell_runner,
                cell,
                presets,
                workload_dataset,
                duration_sec,
                max_requests,
                retain_records,
            )
            for cell in cells
        ]
        completed = as_completed(futures)
        with _section_progress(
            completed,
            total=len(futures),
            desc="RouteWise cells",
        ) as progress:
            for future in progress:
                result = future.result()
                _set_progress_result(progress, result)
                results.append(result)
    order = {cell: index for index, cell in enumerate(cells)}
    return sorted(
        results,
        key=lambda result: order[
            SectionCell(
                scenario_name=result.scenario_name,
                policy=result.policy,
                seed=result.seed,
            )
        ],
    )


def _section_progress(iterable, *, total: int | None = None, desc: str):
    """Return a polished progress bar for section-level experiment cells."""
    return tqdm(
        iterable,
        total=total,
        desc=desc,
        unit="cell",
        dynamic_ncols=True,
        smoothing=0.1,
        colour="cyan",
    )


def _set_progress_cell(progress, cell: SectionCell) -> None:
    """Show the currently running serial cell without widening the bar too much."""
    progress.set_postfix_str(
        f"{cell.scenario_name} / {cell.policy} / seed={cell.seed}",
        refresh=False,
    )


def _set_progress_result(progress, result: SectionCellResult) -> None:
    """Show the latest completed parallel cell."""
    progress.set_postfix_str(
        f"done {result.scenario_name} / {result.policy} / seed={result.seed}",
        refresh=False,
    )


def _write_section_outputs(
    *,
    root: Path,
    section_name: str,
    scenarios: dict[str, ScenarioConfig],
    policies: tuple[str, ...],
    seeds: tuple[int, ...],
    results: list[SectionCellResult],
    workload_dataset: str,
    duration_sec: float | None,
    max_requests: int | None,
    requests: list[Request],
    jobs: int,
    execution_mode: str,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    histogram_rows: list[dict[str, Any]] = []
    per_seed_histogram_rows: list[dict[str, Any]] = []
    by_group: dict[tuple[str, str], list[Run]] = {
        (scenario.name, policy): [] for scenario in scenarios.values() for policy in policies
    }
    by_seed: dict[tuple[str, str, int], Run] = {}
    for result in results:
        by_group[(result.scenario_name, result.policy)].append(result.run)
        by_seed[(result.scenario_name, result.policy, result.seed)] = result.run

    trace_info = workload_trace_info(requests)
    for scenario in scenarios.values():
        for policy in policies:
            runs = by_group[(scenario.name, policy)]
            aggregate = _merge_run_aggregates(runs)
            rows.append(
                summarize_runs(
                    scenario=scenario,
                    policy=policy,
                    seeds=seeds,
                    runs=runs,
                    requests=requests,
                    trace_info=trace_info,
                )
            )
            histogram_rows.append(
                {
                    "scenario": scenario.name,
                    "policy": policy,
                    "seeds": list(seeds),
                    "histogram": aggregate.ttft_histogram.to_dict(),
                }
            )
            for seed in seeds:
                try:
                    run = by_seed[(scenario.name, policy, seed)]
                except KeyError as exc:
                    raise ValueError(
                        "missing section cell result for "
                        f"scenario={scenario.name!r}, policy={policy!r}, seed={seed}"
                    ) from exc
                if run.aggregate is None:
                    raise ValueError(
                        "run_section requires every run to carry a streaming "
                        f"aggregate; missing for scenario={scenario.name!r}, "
                        f"policy={policy!r}, seed={seed}"
                    )
                per_seed_histogram_rows.append(
                    {
                        "scenario": scenario.name,
                        "policy": policy,
                        "seed": seed,
                        "histogram": run.aggregate.ttft_histogram.to_dict(),
                    }
                )

    metadata = {
        "section": section_name,
        "scenarios": list(scenarios),
        "policies": list(policies),
        "seeds": list(seeds),
        "workload_dataset": workload_dataset,
        "duration_sec": duration_sec,
        "max_requests": max_requests,
        "loaded_requests": trace_info.n_requests,
        "processed_requests_per_cell": trace_info.n_requests,
        "trace_start_sec": trace_info.start_sec,
        "trace_end_sec": trace_info.end_sec,
        "trace_span_sec": trace_info.span_sec,
        "trace_days": trace_info.trace_days,
        "jobs": jobs,
        "execution_mode": execution_mode,
    }
    write_json(root / "metadata.json", metadata)
    write_json(root / "summary.json", rows)
    write_json(root / "ttft_histograms.json", histogram_rows)
    write_json(root / "ttft_histograms_by_seed.json", per_seed_histogram_rows)
    write_summary_csv(root / "summary.csv", rows)
    return rows


def write_json(path: Path, payload: Any) -> None:
    """Write stable JSON output."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def write_summary_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    """Write section summary rows with nested maps JSON-encoded."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "scenario",
        "public_scenario",
        "artifact_label",
        "subscription_plan",
        "subscription_plan_display_name",
        "subscription_count",
        "concurrency_plan",
        "concurrency_plan_display_name",
        "concurrency_count",
        "model",
        "model_class",
        "model_concurrency_cost",
        "prefix_cache_enabled",
        "cached_input_price_fraction",
        "concurrency_capacity_units",
        "effective_concurrency_limit",
        "latency_profile",
        "latency_generation_version",
        "latency_family",
        "latency_anchor_kind",
        "latency_anchor_ms",
        "latency_distribution_mean_ms",
        "latency_distribution_p50_ms",
        "latency_shape",
        "quota_latency_profile_provider",
        "concurrency_latency_profile_provider",
        "api_latency_family",
        "api_latency_generation_version",
        "api_latency_anchor_kind",
        "api_latency_anchor_ms",
        "api_latency_distribution_mean_ms",
        "api_latency_distribution_p50_ms",
        "api_latency_shape",
        "peak_used_concurrency_cost",
        "mean_concurrency_utilization",
        "concurrency_saturated_in_trace",
        "run_count",
        "policy",
        "seeds",
        "n_requests",
        "mean_ttft_ms",
        "p10_ms",
        "p25_ms",
        "p50_ms",
        "p75_ms",
        "p90_ms",
        "p99_ms",
        "mean_api_cost_usd",
        "mean_total_cost_usd",
        "api_cost_usd",
        "api_cost_usd_per_run",
        "subscription_fixed_cost_usd",
        "subscription_fixed_cost_usd_per_run",
        "total_cost_usd",
        "total_cost_usd_per_run",
        "subscription_cost_known",
        "cost_claim_allowed",
        "trace_paper_grade",
        "quota_fits_in_trace",
        "trace_days",
        "slo_violation_rate",
        "hedge_rate",
        "provider_mix",
        "tier_mix",
        "percentile_source",
        "histogram_bins",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    key: (
                        json.dumps(row[key], sort_keys=True)
                        if isinstance(row.get(key), (dict, list))
                        else row.get(key)
                    )
                    for key in fieldnames
                }
            )


def _fraction_map(counts: Counter[str], total: int) -> dict[str, float]:
    if total <= 0:
        return {}
    return {key: counts[key] / total for key in sorted(counts)}


def _merge_run_aggregates(runs: list[Run]) -> RunAggregate:
    for run in runs:
        if run.aggregate is None:
            raise ValueError(
                "run_section requires every run to carry a streaming aggregate"
            )
    aggregate = RunAggregate(
        ttft_histogram=merge_histograms([run.ttft_histogram() for run in runs])
    )
    for run in runs:
        source = run.aggregate
        aggregate.n += source.n
        if source.e2e_histogram is not None:
            if aggregate.e2e_histogram is None:
                aggregate.e2e_histogram = source.e2e_histogram.copy()
            else:
                aggregate.e2e_histogram = aggregate.e2e_histogram.merge(
                    source.e2e_histogram
                )
        aggregate.total_cost_usd += source.total_cost_usd
        aggregate.cost_count += source.cost_count
        aggregate.status_counts.update(source.status_counts)
        aggregate.slo_violated_count += source.slo_violated_count
        aggregate.cost_by_tier.update(source.cost_by_tier)
        aggregate.cost_by_provider.update(source.cost_by_provider)
        aggregate.provider_counts.update(source.provider_counts)
        aggregate.tier_counts.update(source.tier_counts)
        aggregate.hedge_triggered_count += source.hedge_triggered_count
        aggregate.hedge_total_count += source.hedge_total_count
        aggregate.hedge_winner_counts.update(source.hedge_winner_counts)
    return aggregate


__all__ = [
    "COST_LAYER_LATENCY_ANCHOR_MS",
    "COST_RATIO_PER_MILLION",
    "DEFAULT_CACHED_INPUT_PRICE_FRACTION",
    "DEFAULT_SEEDS",
    "DEFAULT_WORKLOAD",
    "OUTPUT_COST_MULTIPLIER",
    "OUTPUT_DIR",
    "P_SWEEP",
    "WORKLOAD_CHOICES",
    "WORKLOAD_COST_ENVELOPE",
    "SectionCell",
    "SectionCellResult",
    "WorkloadTraceInfo",
    "concurrency_saturated_in_trace",
    "ensure_workload_cache",
    "load_workload",
    "make_api_provider",
    "make_concurrency_provider",
    "make_quota_provider",
    "make_routewise_presets",
    "make_ttft_distribution",
    "p_label",
    "quota_fits_in_trace",
    "routewise_hedging_policy_name",
    "routewise_lp_policy_name",
    "run_policy",
    "run_section",
    "summarize_runs",
    "workload_cost_envelope",
    "workload_trace_info",
    "write_json",
    "write_summary_csv",
]
