"""Paper ablation experiment helpers."""
